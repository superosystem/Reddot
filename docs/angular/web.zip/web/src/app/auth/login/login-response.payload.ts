export interface LoginResponse {
  message: string;
  status: string;
  data: LoginResponseData
}

export interface LoginResponseData {
  username: string;
  token: string;
  expired_at: Date;
  refresh_token: string;
}
