export interface SignupRequestPayload {
  name: string;
  username: string;
  password: string;
  email: string;
}
