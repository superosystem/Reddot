import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { PostModel, PostsResponsePayload } from './post-model';
import { map, Observable } from 'rxjs';
import { CreatePostPayload } from '../post/create-post/create-post.payload';

@Injectable({
  providedIn: 'root'
})
export class PostService {

  constructor(private http: HttpClient) { }

  getAllPosts(): Observable<any> {
    return this.http.get<PostsResponsePayload>('http://localhost:8080/api/v1/posts')
    .pipe(map(result => {
      let data: Array<PostModel> = result.data
      console.log(data)
    }));
  }

  createPost(postPayload: CreatePostPayload): Observable<any> {
    return this.http.post('http://localhost:8080/api/v1/posts/', postPayload);
  }

  getPost(id: number): Observable<PostModel> {
    return this.http.get<PostModel>('http://localhost:8080/api/v1/posts/' + id);
  }

  getAllPostsByUser(name: string): Observable<PostModel[]> {
    return this.http.get<PostModel[]>('http://localhost:8080/api/v1/posts/by-user/' + name);
  }
}
